var WL_CHECKSUM = {"checksum":1040854690,"date":1459787682785,"machine":"carlosmacbookpro.raleigh.ibm.com"}
/* Date: Mon Apr 04 2016 12:34:42 GMT-0400 (EDT) */