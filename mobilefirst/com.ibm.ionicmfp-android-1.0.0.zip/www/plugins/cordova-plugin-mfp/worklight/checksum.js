var WL_CHECKSUM = {"checksum":3706256278,"date":1459786004097,"machine":"carlosmacbookpro.raleigh.ibm.com"}
/* Date: Mon Apr 04 2016 12:06:44 GMT-0400 (EDT) */