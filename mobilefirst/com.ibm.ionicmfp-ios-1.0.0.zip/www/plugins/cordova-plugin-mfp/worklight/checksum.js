var WL_CHECKSUM = {"checksum":564641579,"date":1459786013064,"machine":"carlosmacbookpro.raleigh.ibm.com"}
/* Date: Mon Apr 04 2016 12:06:53 GMT-0400 (EDT) */